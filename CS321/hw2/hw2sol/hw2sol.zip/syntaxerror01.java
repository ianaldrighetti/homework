// Syntax error: class misspelled.
clas MyClass {
	public static void main(String[] args) {
		System.out.println("Hi!");
	}
}