// Syntax error: method without closing bracket.
class MyClass {
	
	public int getMe5() {
		return 5;
}