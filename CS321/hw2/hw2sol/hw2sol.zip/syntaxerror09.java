// Syntax error: string literal within an expression.
class MyClass {

	public boolean check() {
		return ("String Literal" && "String Literal");
	}
}