// Syntax error: return without semicolon.
class MyClass {
	
	public int getMe5() {
		return 5
	}
}