// Syntax error: variable declaration after method declaration.
class MyClass extends AnotherClass {

	public static void main(String[] args) {
		System.out.println("Hey there...");
	}
	
	int integer = 1;
}