// Syntax error: parameter without type.
class MyClass {
	
	public int myMethod(int a, b) {
		return a + b;
	}
}