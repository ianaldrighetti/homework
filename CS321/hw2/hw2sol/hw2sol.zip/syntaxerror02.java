// Syntax error: missing { after class declaration.
class MyClass extends AnotherClass 
	public static void main(String[] args) {
	
	}
}