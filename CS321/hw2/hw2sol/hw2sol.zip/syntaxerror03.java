// Syntax error: extends with no ID.
class MyClass extends {

	public static void main(String[] args) {
		System.out.println("Hey there...");
	}
}