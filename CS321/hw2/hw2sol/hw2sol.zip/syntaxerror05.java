// Syntax error: no return type on method declaration.
class MyClass {

	public myMethod(int a, int b) {
		return a + b;
	}
}