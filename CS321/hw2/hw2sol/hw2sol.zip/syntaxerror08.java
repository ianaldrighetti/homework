// Syntax error: variable declaration after statement.
class MyClass {

	public void displayMessage(string message) {
		System.out.println(message);
		int a = 1;
	}
}