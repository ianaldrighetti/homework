// Syntax error: public static out of order.
class MyClass {

	static public void main(String[] args) {
		System.out.println("My static method!");
	}
}